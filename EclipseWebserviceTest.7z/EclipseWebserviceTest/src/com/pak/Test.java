package com.pak;

public class Test {
public float addvalue(float b)
{
	return b+10;
}

public float subvalue(float a)
{
	return a-10;
}
}
